//
//  BRSettingViewController.h
//  BuDeJie
//
//  Created by 熊欣 on 16/9/14.
//  Copyright © 2016年 熊欣. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BRBaseViewController.h"

@interface BRSettingViewController : BRBaseViewController

@end
