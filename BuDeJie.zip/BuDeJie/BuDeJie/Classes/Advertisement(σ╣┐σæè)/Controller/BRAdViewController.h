//
//  BRAdViewController.h
//  BuDeJie
//
//  Created by 熊欣 on 16/9/18.
//  Copyright © 2016年 熊欣. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BRAdViewController : UIViewController

@end
