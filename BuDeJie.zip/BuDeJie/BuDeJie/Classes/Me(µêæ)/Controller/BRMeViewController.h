//
//  BRMeViewController.h
//  BuDeJie
//
//  Created by 熊欣 on 16/9/12.
//  Copyright © 2016年 熊欣. All rights reserved.
//

#import "BRBaseViewController.h"

@interface BRMeViewController : BRBaseViewController

@end
