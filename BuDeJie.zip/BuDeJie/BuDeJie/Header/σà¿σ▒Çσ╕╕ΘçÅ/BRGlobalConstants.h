//
//  BRGlobalConstants.h
//  BuDeJie
//
//  Created by 熊欣 on 16/9/13.
//  Copyright © 2016年 熊欣. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface BRGlobalConstants : NSObject


/** 全局字体大小*/
extern NSInteger const BRFontSize;

extern NSInteger const BRStatusBarHeight;

extern NSInteger const BRNavBarHeight;

extern NSInteger const BRTabBarHeight;



@end
