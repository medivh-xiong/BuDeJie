//
//  BRGlobalConstants.m
//  BuDeJie
//
//  Created by 熊欣 on 16/9/13.
//  Copyright © 2016年 熊欣. All rights reserved.
//

#import "BRGlobalConstants.h"

@implementation BRGlobalConstants


NSInteger const BRFontSize        = 16;

NSInteger const BRNavBarHeight    = 44;

NSInteger const BRTabBarHeight    = 49;

NSInteger const BRStatusBarHeight = 20;


@end
